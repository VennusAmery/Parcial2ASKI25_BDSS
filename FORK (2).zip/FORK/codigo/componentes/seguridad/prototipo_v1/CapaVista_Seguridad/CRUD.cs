﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaControlador_Seguridad;
using Capa_Controlador_Navegador;
using System.Diagnostics;

namespace CapaVista_Seguridad
{
    public partial class CRUD : Form
    {
        public CRUD()
        {
            InitializeComponent();
            //parametros para navegador
            Capa_Controlador_Navegador.Cls_ConfiguracionDataGridView config = new Capa_Controlador_Navegador.Cls_ConfiguracionDataGridView
            {
                Ancho = 1100,
                Alto = 500,
                ColorFondo = Color.White,
                TipoScrollBars = ScrollBars.Both,
                Nombre = "dgv_empleados"
            };
            string[] columnas = {
                        "bodegas", "codigo_bodega", "nombre_bodega", "estatus_bodega"
            //"tbl_aplicacion",            
            //"Pk_Id_Aplicacion",
            //"Fk_Id_Reporte_Aplicacion",
            //"Cmp_Nombre_Aplicacion",
            //"Cmp_Descripcion_Aplicacion",
            //"Cmp_Estado_Aplicacion"
        };
            //int id_aplicacion = 100;

            //navegador1.IPkId_Aplicacion = id_aplicacion;
            navegador1.configurarDataGridView(config);
            navegador1.SNombreTabla = columnas[0];
            navegador1.SAlias = columnas;
            navegador1.mostrarDatos();

        }

        private void btn_ayuda_Click(object sender, EventArgs e)
        {

        }

        private void btn_reporte_Click(object sender, EventArgs e)
        {
            CapaVista_Seguridad.reporte bitacora = new CapaVista_Seguridad.reporte();
            bitacora.ShowDialog();
        }
    }
}
