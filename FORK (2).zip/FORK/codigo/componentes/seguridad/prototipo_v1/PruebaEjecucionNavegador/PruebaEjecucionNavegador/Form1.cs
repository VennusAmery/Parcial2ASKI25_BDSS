﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PruebaEjecucionNavegador
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            //parametros para navegador
            Capa_Controlador_Navegador.Cls_ConfiguracionDataGridView config = new Capa_Controlador_Navegador.Cls_ConfiguracionDataGridView
            {
                Ancho = 1100,
                Alto = 200,
                ColorFondo = Color.White,
                TipoScrollBars = ScrollBars.Both,
                Nombre = "dgv_empleados"
            };
            string[] columnas = {
                        "bodegas", "codigo_bodega", "nombre_bodega", "estatus_bodega"
            //"tbl_aplicacion",            
            //"Pk_Id_Aplicacion",
            //"Fk_Id_Reporte_Aplicacion",
            //"Cmp_Nombre_Aplicacion",
            //"Cmp_Descripcion_Aplicacion",
            //"Cmp_Estado_Aplicacion"
        };
            //int id_aplicacion = 100;

            //navegador1.IPkId_Aplicacion = id_aplicacion;
            navegador1.configurarDataGridView(config);
            navegador1.SNombreTabla = columnas[0];
            navegador1.SAlias = columnas;
            navegador1.mostrarDatos();
        }

    }
}
